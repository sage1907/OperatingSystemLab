#include <stdio.h>

int main() {
    printf("Hello, this is executable 1!\n");
    return 0;
}
