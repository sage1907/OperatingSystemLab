#include <stdio.h>

int main() {
    int a = 3, b = 7;
    printf("Sum of %d and %d is %d (executable 3)\n", a, b, a + b);
    return 0;
}
