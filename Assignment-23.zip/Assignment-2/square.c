#include <stdio.h>

int main() {
    int num = 5;
    printf("Square of %d is %d (executable 2)\n", num, num * num);
    return 0;
}
